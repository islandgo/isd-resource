<?php get_header(); ?>

	<!-- your home html -->

	<!-- your home html -->

<?php get_footer(); ?>
